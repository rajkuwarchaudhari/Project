package com.example.demo;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.rajkuwar.entity.Calculate;
import com.rajkuwar.service.CalculatorService;

@SpringBootTest
class CalculatorApplicationTests {
 
	@Autowired
	CalculatorService cal;
	
	@Test
	void contextLoads() {
	}

	
}
