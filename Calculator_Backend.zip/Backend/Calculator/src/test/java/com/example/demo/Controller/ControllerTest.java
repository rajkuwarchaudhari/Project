package com.example.demo.Controller;


import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.rajkuwar.controller.CalculatorController;
import com.rajkuwar.repo.CalculatorRepo;
import com.rajkuwar.service.CalculatorService;

public class ControllerTest {
	
	@Autowired
	MockMvc mockmvc;

	@MockBean
	CalculatorService calService;
	
	@MockBean
	CalculatorRepo calRepo;
	
	@Autowired
	CalculatorController calCalculator;
	
	@Test
	void calculatingtest () {
		List<String> list=new ArrayList<>();
		list.add("30");
		list.add("+");
		list.add("6");
		//when(calService.calculateOperation(list)).thenReturn((float)36);
		try {
			mockmvc
			.perform(post("/equals",list)).andExpect(status().isOk())
			.andExpect(MockMvcResultMatchers.jsonPath("$.size()", Matchers.is(1)))
			.andExpect(MockMvcResultMatchers.jsonPath("$[0]").value("36"));
			
			
			 
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	@Test
	  public void negativecalculatingTest() throws Exception {
		 List<String> list=new ArrayList<>();
			list.add("30");
			list.add("+");
			 
	    mockmvc.perform(post("/equals",list))
	      .andExpect(status().isInternalServerError());
	  }
	
	@Test
	void savetest() {
		List<String> list=new ArrayList<>();
		list.add("30");
		list.add("+");
		try {
			mockmvc
			.perform(post("/save",list)).andExpect(status().isOk());
			
			
			
			 
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	
	 @Test
	  public void negatviesaveTest() throws Exception {
		 List<String> list=new ArrayList<>();
			list.add("30");
			
	    mockmvc.perform(post("/save",list))
	      .andExpect(status().isInternalServerError());
	  }
	 
	@Test
	void resulttest() {
		List<String> list=new ArrayList<>();
		list.add("30");
		list.add("+");
		try {
			mockmvc
			.perform(get("/result")).andExpect(status().isOk()).andExpect(MockMvcResultMatchers.jsonPath("$.size()", Matchers.is(1)));
			
			 
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	
	 
	@Test
	void cleartest() {
		
		try {
			mockmvc
			.perform(get("/save")).andExpect(status().isOk());
			
			 
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	 
}
