package com.example.demo.Service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.rajkuwar.entity.Calculate;
import com.rajkuwar.entity.MemoryCalculator;
import com.rajkuwar.repo.CalculatorRepo;
import com.rajkuwar.service.CalculatorService;

@SpringBootTest
public class CalculatorServiceTest {

	@MockBean
	private CalculatorRepo calRepo;
	
	private MemoryCalculator cal;
	
	@Autowired
	private CalculatorService calService;
	
	@Test
	void testcalculateOperation() {
		List<String> list=new ArrayList<>();
		list.add("8");
		list.add("+");
		list.add("5");
		
		float expectedResult=13;
		float actualResult = calService.calculateOperation(list);
		assertThat(actualResult).isEqualTo(expectedResult);
	}
	@Test
	void negativetestcalculateOperation() {
		List<String> list=new ArrayList<>();
		list.add("8");
		list.add("+");
		list.add("5");
		
		float expectedResult=18;
		float actualResult = calService.calculateOperation(list);
		assertNotEquals(actualResult,expectedResult);
	}
	@Test
	void testmemorySave() {
		
		List<String> list=new ArrayList<>();
		list.add("96");
		list.add("-");
		
		//assertSame(cal, calService.memorySave(list));
	}
	
	@Test
	void testmemoryResult() {
		List<Float> list=new ArrayList<>();
		list.add((float) 8.0);
		list.add((float)-9.0);
		list.add((float)+10);
		MemoryCalculator value=new MemoryCalculator(Float.valueOf(list.get(1)+list.get(0)));
		when(calRepo.findAllResult()).thenReturn(list);
		float actualResult=calService.memoryResult();
		float expectedResult= 9;
		assertThat(actualResult).isEqualTo(expectedResult);
	}
	
	@Test
	void nagetivetestmemoryResult() {
		List<Float> list=new ArrayList<>();
		list.add((float) 8.0);
		list.add((float)-9.0);
		list.add((float)+10);
		MemoryCalculator value=new MemoryCalculator(Float.valueOf(list.get(1)+list.get(0)));
		when(calRepo.findAllResult()).thenReturn(list);
		float actualResult=calService.memoryResult();
		float expectedResult= 12;
		assertNotEquals(actualResult,expectedResult);
	}
}
