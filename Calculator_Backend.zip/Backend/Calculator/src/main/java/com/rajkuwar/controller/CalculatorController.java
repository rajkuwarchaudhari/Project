package com.rajkuwar.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.rajkuwar.entity.Calculate;
import com.rajkuwar.entity.MemoryCalculator;
import com.rajkuwar.service.CalculatorService;

@RestController
@CrossOrigin("http://localhost:3000")
public class CalculatorController {

	@Autowired
	public CalculatorService calService;
	
	@PostMapping("/equals")
	public List<String> calculating(@RequestBody List<String> equation) {
		List<String> list=new ArrayList<>();
		list.add(Float.toString(calService.calculateOperation(equation)));
		System.out.println(list.size());
		return list;
	}
	
	@PostMapping("/save")
	public void save(@RequestBody List<String> cal) {
		 calService.memorySave(cal);
	}
	
	@GetMapping("/result")
	public float result() {
		return calService.memoryResult();
	}
	
	@GetMapping("/clear")
	public void clear() {
		 calService.memoryClear();
	}
	
	
	
}
