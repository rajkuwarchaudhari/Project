package com.rajkuwar.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class MemoryCalculator {

	@Id 
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int id;
	
	private float result;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public float getResult() {
		return result;
	}

	public void setResult(float result) {
		this.result = result;
	}

	public MemoryCalculator(float result) {
		super();
		
		this.result = result;
	}

	public MemoryCalculator() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "MemoryCalculator [id=" + id + ", result=" + result + "]";
	}
	
}
