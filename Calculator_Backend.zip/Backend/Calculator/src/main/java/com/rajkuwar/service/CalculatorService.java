package com.rajkuwar.service;

import java.util.List;

import com.rajkuwar.entity.Calculate;
import com.rajkuwar.entity.MemoryCalculator;

public interface CalculatorService {

	public float calculateOperation( List<String> equation);
	public void memorySave(List<String> result);
	public float memoryResult();
	public void memoryClear();
}
