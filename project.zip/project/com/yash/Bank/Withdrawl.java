package com.yash.Bank;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Withdrawl extends JFrame implements ActionListener {
	JLabel l1, l2, l3, l4;
	JTextField t1, t2, t3;
	JButton b1, b2;

	public Withdrawl() {
		setBounds(150, 80, 680, 554);
		setVisible(true);
		setLayout(null);

		l1 = new JLabel("Withdraw Money");
		l1.setBounds(190, 50, 230, 40);
		add(l1);

		l2 = new JLabel("enter pin");
		l2.setBounds(110, 120, 160, 30);
		add(l2);

		t1 = new JTextField();
		t1.setBounds(290, 130, 220, 30);
		add(t1);

		l3 = new JLabel("enter amount");
		l3.setBounds(110, 190, 160, 30);
		add(l3);

		t2 = new JTextField();
		t2.setBounds(290, 190, 220, 30);
		add(t2);

		b1 = new JButton("Wuthdrwal");
		b1.setBounds(140, 270, 150, 30);
		add(b1);
		b1.addActionListener(this);

		b2 = new JButton("Cancel");
		b2.setBounds(320, 270, 150, 30);
		add(b2);
		b2.addActionListener(this);

	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == b1) {
			try {
				// Step1: load the driver
				Class.forName("com.mysql.cj.jdbc.Driver");

				// Step2: create connection
				String url = "jdbc:mysql://localhost:3306/BankProject";
				String user = "root";
				String pass = "root";
				Connection con = DriverManager.getConnection(url, user, pass);
				if (con != null) {
					System.out.println("connection done successfully");
				} else {
					System.out.println("connection not done");
				}
				String a = "select * from login where pin='" + t1.getText() + "'";
				PreparedStatement ps = con.prepareStatement(a);// prepareStatement
				ResultSet rs = ps.executeQuery();
				if (rs.next()) {
					int bal = rs.getInt(3);
					int amount = Integer.parseInt(t2.getText());
					int rem_amt = bal - amount;

					if (bal > amount) {
						String q = "update login set balance='" + rem_amt + "' where pin='" + t1.getText() + "'";
						ps.executeUpdate(q);
						JOptionPane.showMessageDialog(null, "Money Withdrawal sucessful");
						t1.setText("");
						t2.setText("");
					} else {
						JOptionPane.showMessageDialog(null, "Insuffient balance");
					}
				} else {
					JOptionPane.showMessageDialog(null, "Enter correct pin");
				}
			} catch (SQLException ex) {
				ex.printStackTrace();
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} else {
			setVisible(false);
			new Transaction();
		}

	}

	public static void main(String args[]) {
		new Withdrawl();
	}

}
