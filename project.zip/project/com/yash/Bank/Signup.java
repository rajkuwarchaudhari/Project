package com.yash.Bank;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Random;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Signup extends JFrame implements ActionListener {
	JLabel l1, l2, l3, l4, l5, l6, l7, l8;
	JTextField t1, t2, t3;
	JComboBox c1, c2, c3;
	JRadioButton r1, r2, r3;
	ButtonGroup bg;
	JTextArea ta1;
	JButton b1, b2;
	String day[] = new String[31];
	String year[] = new String[33];
	String month[] = new String[12];
	int no;

	public Signup()// constructor
	{
		super("BANK MANAGEMENT");
		setBounds(150, 80, 678, 560);// this is for the Boundry
		setVisible(true);
		setLayout(null);

		Random r = new Random();
		no = 100 + r.nextInt(999 - 100);

		l1 = new JLabel("Application Form" + no);
		l1.setBounds(250, 10, 460, 50);
		add(l1);

		l2 = new JLabel("Page1 : Personal Information");
		l2.setBounds(240, 60, 220, 30);
		add(l2);

		l3 = new JLabel("Name");
		l3.setBounds(50, 130, 160, 30);
		add(l3);
		t1 = new JTextField();
		t1.setBounds(240, 130, 320, 20);
		add(t1);

		l4 = new JLabel("Contact No");
		l4.setBounds(50, 180, 170, 30);
		add(l4);
		t2 = new JTextField();
		t2.setBounds(240, 180, 320, 30);
		add(t2);

		l5 = new JLabel("Gender");
		l5.setBounds(50, 230, 170, 30);
		add(l5);
		r1 = new JRadioButton("Male");
		r1.setBounds(240, 230, 80, 30);
		add(r1);
		r2 = new JRadioButton("FEMALE", true);
		r2.setBounds(360, 230, 80, 30);
		add(r2);
		r3 = new JRadioButton("OTHERS");
		r3.setBounds(480, 230, 80, 30);
		add(r3);

		bg = new ButtonGroup();
		bg.add(r1);
		bg.add(r2);
		bg.add(r3);

		l6 = new JLabel("Date of Birth");
		l6.setBounds(50, 280, 170, 30);
		add(l6);

		// days
		for (int i = 1; i <= 31; i++) {
			day[i - 1] = String.valueOf(i);
		}
		c1 = new JComboBox(day);
		c1.setBounds(240, 280, 60, 30);
		add(c1);

		// month
		for (int i = 1; i <= 12; i++) {
			month[i - 1] = String.valueOf(i);
		}
		c2 = new JComboBox(month);
		c2.setBounds(330, 280, 110, 30);
		add(c2);

		// year
		for (int i = 1990; i <= 2022; i++) {
			year[i - 1990] = String.valueOf(i);
		}
		c3 = new JComboBox(year);
		c3.setBounds(480, 280, 80, 30);
		add(c3);

		l7 = new JLabel("Email");
		l7.setBounds(50, 330, 170, 30);
		add(l7);
		t3 = new JTextField();
		t3.setBounds(240, 330, 320, 30);
		add(t3);

		l8 = new JLabel("Address");
		l8.setBounds(50, 380, 170, 30);
		add(l8);
		ta1 = new JTextArea();
		ta1.setBounds(240, 380, 320, 30);
		add(ta1);

		b1 = new JButton("NEXT");
		b1.setBounds(240, 450, 110, 30);
		add(b1);
		b1.addActionListener(this);

		b2 = new JButton("Cancel");
		b2.setBounds(380, 450, 110, 30);
		add(b2);
		b2.addActionListener(this);

	}

	public void actionPerformed(ActionEvent e) {
		String name, contact, gender = "", dob = "", gmail, address;
		name = t1.getText();
		Pattern p = Pattern.compile("[a-z A-Z]*");
		Matcher m = p.matcher(name);
		if (m.find()) {
			System.out.println("Valid name");
		} else {
			JOptionPane.showMessageDialog(null, "wrong name");
		}
		contact = t2.getText();
		Pattern p1 = Pattern.compile("^[6 7 8 9][0-9]{9}$");
		Matcher m1 = p1.matcher(contact);
		if (m1.find()) {
			System.out.println("contact valid");
		} else {
			JOptionPane.showMessageDialog(null, "contact not valid");
		}
		if (r1.isSelected()) {
			gender = "Male";
		} else if (r2.isSelected()) {
			gender = "Female";
		} else if (r3.isSelected()) {
			gender = "Others";
		}
		dob = String.valueOf(c3.getSelectedItem()) + "-" + String.valueOf(c2.getSelectedItem()) + "-"
				+ String.valueOf(c1.getSelectedItem());
		gmail = t3.getText();
		Pattern p2 = Pattern.compile("^[\\w_\\-\\.]+[@][a-z]+[\\.][a-z]{2,3}$");
		Matcher m2 = p2.matcher(gmail);
		if (m2.find()) {
			System.out.println("gmail valid");
		} else {
			JOptionPane.showMessageDialog(null, "gmail not valid");
		}
		address = ta1.getText();
		Pattern p3 = Pattern.compile("^[\\w\\W\\s]*$");
		Matcher m3 = p3.matcher(address);
		if (m3.find()) {
			System.out.println("address valid");
		} else {
			JOptionPane.showMessageDialog(null, "ADDRESS not valid");
		}
		if (e.getSource() == b1) {
			if (name.equals("") || gmail.equals("") || address.equals("")) {
				JOptionPane.showMessageDialog(null, "cannot leave the field empty");
			} else {
				String q = "insert into Signup values('" + no + "','" + name + "','" + contact + "','" + gender + "','"
						+ dob + "','" + gmail + "','" + address + "')";
				try {
					// Step1: load the driver
					Class.forName("com.mysql.cj.jdbc.Driver");

					// Step2: create connection
					String url = "jdbc:mysql://localhost:3306/BankProject";
					String user = "root";
					String pass = "root";
					Connection con = DriverManager.getConnection(url, user, pass);
					if (con != null) {
						System.out.println("connection done successfully");
					} else {
						System.out.println("connection not done");
					}

					PreparedStatement ps = con.prepareStatement(q);// prepareStatement
					ps.execute(q);
					JOptionPane.showMessageDialog(null, "Data inserted successfully");
					setVisible(false);
					new SignupA(no);// no is primary key that is id
					con.close();
				} catch (SQLException ex) {
					ex.printStackTrace();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}

		} else {
			setVisible(false);

		}

	}

	public static void main(String[] args) {
		new Signup();
	}

}
