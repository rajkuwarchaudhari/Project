package com.yash.Bank;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class Transaction extends JFrame implements ActionListener {
	JLabel l1;
	JButton b1, b2, b3, b4, b5;

	public Transaction() {
		setBounds(150, 80, 680, 554);
		setVisible(true);
		setLayout(null);

		l1 = new JLabel("Select Transation");
		l1.setBounds(150, 40, 350, 40);
		add(l1);

		b1 = new JButton("Pin Changed");
		b1.setBounds(80, 130, 200, 30);
		add(b1);
		b1.addActionListener(this);

		b2 = new JButton("Balance enquiry");
		b2.setBounds(310, 120, 210, 30);
		add(b2);
		b2.addActionListener(this);

		b3 = new JButton("Deposite");
		b3.setBounds(80, 210, 200, 30);
		add(b3);
		b3.addActionListener(this);

		b4 = new JButton("Withdrwal");
		b4.setBounds(310, 210, 210, 30);
		add(b4);
		b4.addActionListener(this);

		b5 = new JButton("Exit");
		b5.setBounds(210, 270, 180, 40);
		add(b5);
		b5.addActionListener(this);

	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == b1) {
			setVisible(false);
			new ChangePin();
		} else if (e.getSource() == b2) {
			try {
				String pin = JOptionPane.showInputDialog("enter you pin");
				// Step1: load the driver
				Class.forName("com.mysql.cj.jdbc.Driver");

				// Step2: create connection
				String url = "jdbc:mysql://localhost:3306/BankProject";
				String user = "root";
				String pass = "root";
				Connection con = DriverManager.getConnection(url, user, pass);
				if (con != null) {
					System.out.println("connection done successfully");
				} else {
					System.out.println("connection not done");
				}

				String q = "select * from login where pin='" + pin + "' ";
				PreparedStatement ps = con.prepareStatement(q);
				ResultSet rs = ps.executeQuery();

				if (rs.next()) {
					int balance = rs.getInt(3);
					JOptionPane.showMessageDialog(null, "your Balance is" + balance);
				} else {
					JOptionPane.showMessageDialog(null, "Wrong pin entered");
				}
			} catch (SQLException ex) {
				ex.printStackTrace();
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		if (e.getSource() == b3) {
			setVisible(false);
			new Deposite();
		}
		if (e.getSource() == b4) {
			setVisible(false);
			new Withdrawl();
		}
		if (e.getSource() == b5) {
			setVisible(false);
			System.exit(0);
		}
	}

	public static void main(String[] args) {
		new Transaction();
	}
}
