package com.yash.Bank;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class ChangePin extends JFrame implements ActionListener {
	JLabel l1, l2, l3, l4;
	JTextField t1, t2, t3;
	JButton b1, b2;

	public ChangePin() {
		setBounds(150, 80, 680, 554);
		setVisible(true);
		setLayout(null);

		l1 = new JLabel("Change pin");
		l1.setBounds(190, 50, 230, 40);
		add(l1);

		l2 = new JLabel("Enter the old pin");
		l2.setBounds(80, 130, 160, 30);
		add(l2);

		t1 = new JTextField();
		t1.setBounds(290, 130, 220, 30);
		add(t1);

		l3 = new JLabel("Enter the new pin");
		l3.setBounds(80, 190, 220, 30);
		add(l3);

		t2 = new JTextField();
		t2.setBounds(290, 190, 220, 30);
		add(t2);

		l4 = new JLabel("Re-Enter the new pin");
		l4.setBounds(80, 250, 160, 30);
		add(l4);

		t3 = new JTextField();
		t3.setBounds(290, 250, 220, 30);
		add(t3);

		b1 = new JButton("Change");
		b1.setBounds(140, 320, 110, 30);
		add(b1);
		b1.addActionListener(this);

		b2 = new JButton("Cancel");
		b2.setBounds(280, 320, 110, 30);
		add(b2);
		b2.addActionListener(this);

	}

	public void actionPerformed(ActionEvent e) {
		try {
			// Step1: load the driver
			Class.forName("com.mysql.cj.jdbc.Driver");

			// Step2: create connection
			String url = "jdbc:mysql://localhost:3306/BankProject";
			String user = "root";
			String pass = "root";
			Connection con = DriverManager.getConnection(url, user, pass);
			if (con != null) {
				System.out.println("connection done successfully");
			} else {
				System.out.println("connection not done");
			}

			String q = "select * from SignupB where pin='" + t1.getText() + "'";
			PreparedStatement ps = con.prepareStatement(q);// prepareStatement

			ResultSet rs = ps.executeQuery();
			if (e.getSource() == b1) {
				if (rs.next()) {
					if (t2.getText().length() == 4) {
						if (t2.getText().equals(t3.getText())) {
							String q1 = "update SignupB set pin='" + t2.getText() + "'where pin='" + t1.getText() + "'";
							ps.execute(q1);
							String q2 = "update Login set pin='" + t2.getText() + "'where pin='" + t1.getText() + "'";
							ps.execute(q2);

							JOptionPane.showMessageDialog(null, "Pin changed sucessfully");
							t1.setText("");
							t2.setText("");
							t3.setText("");
							setVisible(false);
							new Transaction();
						} else {
							JOptionPane.showMessageDialog(null, "Chcek pin length");
						}
					} else {
						JOptionPane.showMessageDialog(null, "pin not matched");
					}
				} else {
					JOptionPane.showMessageDialog(null, "pin is wrong");
				}
			} else if (e.getSource() == b2) {
				setVisible(false);
				new Transaction();
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
	}

	public static void main(String args[]) {
		new ChangePin();
	}

}
