package com.yash.Bank;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Login extends JFrame implements ActionListener {
	JLabel l1, l2, l3;
	JTextField t1, t2, t3;
	JButton b1, b2, b3;
	ResultSet rs;

	public Login() throws SQLException {
		super("BANK MANAGEMENT");
		setBounds(260, 200, 860, 484);
		setVisible(true);
		setLayout(null);

		l1 = new JLabel("Welcome to the BANK");
		l1.setBounds(20, 30, 460, 50);
		add(l1);

		l2 = new JLabel("Card no");
		l2.setBounds(230, 130, 100, 30);
		add(l2);

		t1 = new JTextField();
		t1.setBounds(370, 130, 290, 30);
		add(t1);

		l3 = new JLabel("PIN no");
		l3.setBounds(230, 210, 100, 30);
		add(l3);

		t2 = new JTextField();
		t2.setBounds(370, 210, 290, 30);
		add(t2);

		b1 = new JButton("SIGN IN");
		b1.setBounds(290, 290, 110, 30);
		add(b1);
		b1.addActionListener(this);

		b2 = new JButton("Clear");
		b2.setBounds(450, 290, 110, 30);
		add(b2);
		b2.addActionListener(this);

		b3 = new JButton("SIGN UP");
		b3.setBounds(290, 340, 280, 40);
		add(b3);
		b3.addActionListener(this);

	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == b1) {
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");

				// Step2: create connection
				String url = "jdbc:mysql://localhost:3306/BankProject";
				String user = "root";
				String pass = "root";
				Connection con = DriverManager.getConnection(url, user, pass);
				if (con != null) {
					System.out.println("connection done successfully");
				} else {
					System.out.println("connection not done");
				}
				String q = "select * from SignupB where card='" + t1.getText() + "' and pin='" + t2.getText() + "'";
				PreparedStatement ps = con.prepareStatement(q);// prepareStatement
				ResultSet rs = ps.executeQuery();
				if (rs.next()) {
					setVisible(false);
					new Transaction();
				} else {
					JOptionPane.showMessageDialog(null, "WRONG CARD AND PIN NO");
					t1.setText("");
					t2.setText("");
				}

			} catch (SQLException ex) {
				ex.printStackTrace();
			} catch (ClassNotFoundException e1) {

				e1.printStackTrace();
			}
		} else if (e.getSource() == b2) {
			t1.setText("");
			t2.setText("");
		} else if (e.getSource() == b3) {
			setVisible(false);
			new Signup();
		}
	}

	public static void main(String args[]) throws SQLException {
		new Login();
	}

}
