package com.yash.Bank;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Random;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class SignupB extends JFrame implements ActionListener
{
	JLabel l1,l2,l3,l4,l5,l6,l7,l8;
	JTextField t1;
	JRadioButton r1,r2,r3,r4;
	ButtonGroup bg;
	JButton b1,b2;
	JCheckBox c1,c2,c3,c4;
	Random r20,r21,r22,r23,r24;
	int n1,n2,n3,n4,pin;
	String card, form_no;
	
	public SignupB(String x)
	{
		form_no=x;
		setBounds(150,80,680,554);
		setVisible(true);
		setLayout(null);
		
		l1=new JLabel("Form no");
		l1.setBounds(470,10,60,20);
		getContentPane().add(l1);
		
		t1=new JTextField(form_no);
		t1.setBounds(530,10,70,20);
		add(t1);
		
		l2=new JLabel("Page 3: Account Details");
		l2.setBounds(230,20,220,40);
		getContentPane().add(l2);
		
		l3=new JLabel("Account Type");
		l3.setBounds(70,130,120,30);
		add(l3);
		
		r1=new JRadioButton("Saving Acount");
		r1.setBounds(180,110,130,30);
		add(r1);
		r2=new JRadioButton("Current Acount");
		r2.setBounds(340,110,190,30);
		add(r2);
		r3=new JRadioButton("Fixed Deposite Account");
		r3.setBounds(180,160,130,30);
		add(r3);
		r4=new JRadioButton("Recurring Deposite Acount");
		r4.setBounds(340,160,190,30);
		add(r4);
		
		bg=new ButtonGroup();
		bg.add(r1);
		bg.add(r2);
		bg.add(r3);
		bg.add(r4);
		
		l4=new JLabel("Card Number");
		l4.setBounds(80,220,120,30);
		add(l4);
		
		r24= new Random();
		n4=100+r24.nextInt(999-100);
		
		
		l5=new JLabel("XXXX-XXXX-XXXX" +n4);
		l5.setBounds(240,220,190,30);
		add(l5);
		
		l6=new JLabel("PIN");
		l6.setBounds(80,260,120,30);
		add(l6);
		
		l7=new JLabel("XXXX");
		l7.setBounds(240,260,230,30);
		add(l7);
		
		l8=new JLabel("Servie Required");
		l8.setBounds(70,370,140,30);
		add(l8);
		
		c1=new JCheckBox("ATM CARD");
		c1.setBounds(190,350,120,23);
		add(c1);
		
		c2=new JCheckBox("Net Banking");
		c2.setBounds(340,350,140,23);
		add(c2);
		
		c3=new JCheckBox("Mobile Banking");
		c3.setBounds(190,390,120,23);
		add(c3);
		
		c4=new JCheckBox("E-Statement");
		c4.setBounds(340,395,130,23);
		add(c4);
		
		b1=new JButton("Submit");
		b1.setBounds(200,490,110,30);
		add(b1);
		b1.addActionListener(this);
		
		b2=new JButton("Cancel");
		b2.setBounds(340,490,110,30);
		add(b2);
		b2.addActionListener(this);
		
		r20=new Random();
		pin=100+r20.nextInt(999-100);
		
		r21=new Random();
		n1=100+r21.nextInt(999-100);
		
		r22=new Random();
		n2=100+r22.nextInt(999-100);
		
		r23=new Random();
		n3=100+r23.nextInt(999-100);
		
		card=String.valueOf(n1)+ "-" +String.valueOf(n2)+ "-" +String.valueOf(n3)+ "-"+String.valueOf(n4);
	}
	
	public void actionPerformed(ActionEvent e)
	{
		String account= "", services="";
		if(r1.isSelected())
		{
			account="Saving account";
		}
		else if(r2.isSelected())
		{
			account="Current account";
		}
		else if(r3.isSelected())
		{
			account="Fixed Deposute account";
		}
		else if(r4.isSelected())
		{
			account="Recurring account";
		}
		
		if(c1.isSelected())
		{
			services="ATM Card";
		}
		if(c2.isSelected())
		{
			services="Net Banking";
		}
		if(c3.isSelected())
		{
			services="Mobile Banking";
		}
		if(c4.isSelected())
		{
			services="E=Statement";
		}
		
		if(e.getSource()==b1)
		{
			if(form_no.equals(t1.getText()))
			{
				try
				{
					Class.forName("com.mysql.cj.jdbc.Driver");
					
					//Step2: create connection
					String url="jdbc:mysql://localhost:3306/BankProject";
					String user="root";
					String pass="root";
					Connection con=DriverManager.getConnection(url,user,pass);
					if(con!=null)
					{
						System.out.println("connection done successfully");
					}
					else
					{
						System.out.println("connection not done");
					}
					
					String q="insert into SignupB value('" +form_no+"','" +card+"','" +pin+"','" +account+"','" +services+"')";
					
					PreparedStatement ps=con.prepareStatement(q);//prepareStatement 
					ps.executeUpdate(q);
					int bal=0;
					String q1="insert into login(card,pin,balance) values('" +card+"','" +pin+"','"+bal+"')";
					ps.executeUpdate(q1);
					
					JOptionPane.showMessageDialog(null, "card no is=" +card+ "\n you pin is=" +pin );
					setVisible(false);
					new Transaction();
					con.close();
				}
				catch(SQLException ex)
				{
					ex.printStackTrace();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			else
			{
				JOptionPane.showMessageDialog(null, "check you form");
			}
		}
		else
		{
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				//Step2: create connection
				String url="jdbc:mysql://localhost:3306/BankProject";
				String user="root";
				String pass="root";
				Connection con=DriverManager.getConnection(url,user,pass);
				if(con!=null)
				{
					System.out.println("connection done successfully");
				}
				else
				{
					System.out.println("connection not done");
				}
				//if not completed the form so it get deleted from db
				String p="delete from Signup where id='"+form_no+ "'";
				String p1="delete from SignupA where id='"+form_no+ "'";
				//Step3: create query
				PreparedStatement ps=con.prepareStatement("p,p1");//prepareStatement 
				  
				ps.execute(p);
				//PreparedStatement ps1=con.prepareStatement(p1);
				ps.execute(p1);
				setVisible(false);
			}
			catch(SQLException ex)
			{
				ex.printStackTrace();
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
	public static void main(String [] args)
	{
		String form="123";
		new SignupB(form);
	}
}
