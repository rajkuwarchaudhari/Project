package com.yash.Bank;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class SignupA extends JFrame implements ActionListener
{
	JLabel l1,l2,l3,l4,l5,l6,l7,l8;
	JTextField t1,t2,t3;
	JComboBox c1,c2,c3,c4;
	JButton b1,b2;
	String form_no;
	
	public SignupA(int x)
	{
		form_no=String.valueOf(x);
		 setBounds(150,80,710,527);
		 setVisible(true);
		 setLayout(null);
		 
		 l1=new JLabel("Form no");
		 l1.setBounds(530,10,60,20);
		 getContentPane().add(l1);
		 
		 t1=new JTextField(form_no);
		 t1.setBounds(600,10,70,20);
		 add(t1);
		 
		 l2=new JLabel("Page 2: Additional Details");
		 l2.setBounds(250,50,240,40);
		 getContentPane().add(l2);
		 
		 l3=new JLabel("religion");
		 l3.setBounds(50,130,160,30);
		 add(l3);
		 
		 String religion[]= {"Hindu","Muslim", "Sikh", "Christan", "Others"};//array 
		 
		 c1=new JComboBox(religion);
		 c1.setBounds(240,130,250,30);
		 add(c1);
		 
		 //Category
		 l4=new JLabel("category");
		 l4.setBounds(50,180,170,30);
		 add(l4);
		 
		 String category[]= {"General","OBC", "ST", "SC", "Others"};//array 
		 
		 c2=new JComboBox(category);
		 c2.setBounds(240,180,250,30);
		 add(c2);
			
		 l5=new JLabel("occupation");
		 l5.setBounds(50,230,170,30);
		 add(l5);
		 
		 String occupation[]= {"Self-employed","Salrared", "Business", "Student","Retired", "Others"};//array 
		 
		 c3=new JComboBox(occupation);
		 c3.setBounds(240,230,250,30);
		 add(c3);
		 
		 l6=new JLabel("education");
		 l6.setBounds(50,280,170,30);
		 add(l6);
		 
		 String education[]= {"Graduate","Non Graduate", "Post Graduate", "PHD", "Others"};//array 
		 
		 c4=new JComboBox(education);
		 c4.setBounds(240,280,250,30);
		 add(c4);
		 
		 l7=new JLabel("Adhar Number");
		 l7.setBounds(50,300,190,80);
		 add(l7);
		 t2=new JTextField();
		 t2.setBounds(240,330,250,30);
		 add(t2);
		 
		 l8=new JLabel("PAN Number");
		 l8.setBounds(50,380,170,30);
		 add(l8);
		 t3=new JTextField();
		 t3.setBounds(240,380,250,30);
		 add(t3);
		 
		 b1=new JButton("NEXT");
		 b1.setBounds(240,450,110,30);
		 add(b1);
		 b1.addActionListener(this);
			
		 b2=new JButton("Exit");
		 b2.setBounds(380,450,110,30);
		 add(b2);
		 b2.addActionListener(this);
	}

	public void actionPerformed(ActionEvent e) 
	{
		String form,rel,cat,occ,edu,aad,pan;
		rel=(String) c1.getSelectedItem();//getSelected-> return the object
		cat=(String) c2.getSelectedItem();
		occ=(String) c3.getSelectedItem();
		aad=t2.getText();
		Pattern p=Pattern.compile("[0-9]*{12}");
		Matcher m = p.matcher(aad);
		if(m.find())
		{
			System.out.println("Valid adhar");
		}
		else
		{
			JOptionPane.showMessageDialog(null, "wrong aadhar");
		}
		pan=t3.getText();
		Pattern p1=Pattern.compile("[\\w]*{10}");
		Matcher m1 = p1.matcher(aad);
		if(m1.find())
		{
			System.out.println("Valid pan");
		}
		else
		{
			JOptionPane.showMessageDialog(null, "wrong PAN");
		}
		edu=(String) c4.getSelectedItem();
		form = t1.getText();
		if(e.getSource()==b1)
		{
			if(form_no.equals(form)) 
			{
				if(t1.getText().equals("")|| t2.getText().equals("")) {
					JOptionPane.showMessageDialog(null," check the input field youre not filling everything");
				}else
				{
					
					try
					{
						//Step1: load the driver
						Class.forName("com.mysql.cj.jdbc.Driver");
						
						//Step2: create connection
						String url="jdbc:mysql://localhost:3306/BankProject";
						String user="root";
						String pass="root";
						Connection con=DriverManager.getConnection(url,user,pass);
						if(con!=null)
						{
							System.out.println("connection done successfully");
						}
						else
						{
							System.out.println("connection not done");
						}
						String q="insert into SignupA values('" +form_no+"','" +rel+"','" +cat+"','" +occ+"','" +aad+"','" +pan+"','" +edu+"')";
						PreparedStatement ps=con.prepareStatement(q);//prepareStatement 
						ps.execute(q);
						JOptionPane.showMessageDialog(null, "Data inserted successfully");
						setVisible(false);
						new SignupB(form_no);
						con.close();
					}
					catch(Exception ex)
					{
						ex.printStackTrace();
					}
			    }
		   }
	  }
		else
		   {
			   try
			   {
				   Class.forName("com.mysql.cj.jdbc.Driver");
					
					//Step2: create connection
					String url="jdbc:mysql://localhost:3306/BankProject";
					String user="root";
					String pass="root";
					Connection con=DriverManager.getConnection(url,user,pass);
					if(con!=null)
					{
						System.out.println("connection done successfully");
					}
					else
					{
						System.out.println("connection not done");
					}
				   String q3="delete from Signup where id='" + form_no+"'";
				   PreparedStatement ps=con.prepareStatement(q3);//prepareStatement 
					  
				   ps.execute(q3);
				   setVisible(false);
			   }catch(SQLException ex)
			   {
				   ex.printStackTrace();
			   } catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		   }
	}
	public static void main(String[] args)
	{
		int y=101;
		new SignupA(y);
	}
}
	

