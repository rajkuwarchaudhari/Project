package com.yash.Bank;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Deposite extends JFrame implements ActionListener
{
	JLabel l1,l2;
	JTextField t1,t2;
	JButton b1,b2,b3;
	
	public Deposite()
	{
		setBounds(150,80,680,554);
		setVisible(true);
		setLayout(null);
		
		l1=new JLabel("Enter Pin:");
		l1.setBackground(Color.white);
		l1.setBounds(460,10,70,20);
		add(l1);
		
		t1=new JTextField();
		t1.setBounds(530,10,70,20);
		add(t1);
				
		
		l2=new JLabel("Amount to be deposited");
		l2.setBounds(150,40,400,40);
		add(l2);
		t2=new JTextField();
		t2.setBounds(180,130,280,40);
		add(t2);
		
		b1=new JButton("Deposit");
		b1.setBounds(180,220,120,30);
		add(b1);
		b1.addActionListener(this);
		
		
		b2=new JButton("Cancel");
		b2.setBounds(330,220,130,30);
		add(b2);
		b2.addActionListener(this);
		
		b3=new JButton("Exit");
		b3.setBounds(250,290,130,30);
		add(b3);
		b3.addActionListener(this);
	}
	

	
	public void actionPerformed(ActionEvent e)
	{
		try
		{
			//Step1: load the driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			//Step2: create connection
			String url="jdbc:mysql://localhost:3306/BankProject";
			String user="root";
			String pass="root";
			Connection con=DriverManager.getConnection(url,user,pass);
			if(con!=null)
			{
				System.out.println("connection done successfully");
			}
			else
			{
				System.out.println("connection not done");
			}
			String bal=(t2.getText());
			if(e.getSource()==b1)
			{
				if(t1.getText()==" " || t2.getText()==" ")
				{
					JOptionPane.showMessageDialog(null, "Field is epty");
				}
				else
				{
					String q1="update login set balance=balance+'" +bal+"' where pin='" +t1.getText()+ "' ";
					PreparedStatement ps=con.prepareStatement(q1);//prepareStatement 
			        ResultSet rs = ps.executeQuery();
			        if(rs.next())
					{
						JOptionPane.showMessageDialog(null, "Amount deposited");
						t1.setText("");
						t1.setText("");
					}
					else
					{
						JOptionPane.showMessageDialog(null,"cgeck your pin or amt");
					}
				}
			}else if(e.getSource()==b2)
			{
				setVisible(false);
				new Transaction();
			}else if(e.getSource()==b3)
			{
				System.exit(0);
			}
		}catch(SQLException ex)
		{
			ex.printStackTrace();
		} catch (ClassNotFoundException e1) 
		{
			e1.printStackTrace();
		}
	}
	public static void main(String args[])
	{
		new Deposite();
	}

}
